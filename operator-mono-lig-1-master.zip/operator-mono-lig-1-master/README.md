# operator-mono-lig
A custom font using Operator Mono and Fira-Code styled ligatures.

### Usage
```font-family: Operator Mono Lig, ...```
